#include "ECL_Media.h"
static const uint8_t CONSUMER_RD[] = {
  0x05,0x0C, 0x09,0x01, 0xA1,0x01, 0x85,ECL_RID_CONSUMER,
    0x15,0x00, 0x26,0xFF,0x03, 0x19,0x00, 0x2A,0xFF,0x03, 0x75,0x10, 0x95,0x01, 0x81,0x00,
  0xC0
};
static const uint8_t SYSTEM_RD[] = {
  0x05,0x01, 0x09,0x80, 0xA1,0x01, 0x85,ECL_RID_SYSTEM,
    0x15,0x00, 0x26,0xFF,0x00, 0x19,0x00, 0x2A,0xFF,0x00, 0x75,0x08, 0x95,0x01, 0x81,0x00,
  0xC0
};
const uint8_t* EvilCrowConsumer::reportDescriptor(uint16_t* len){ if(len)*len=sizeof(CONSUMER_RD); return CONSUMER_RD; }
const uint8_t* EvilCrowSystem::reportDescriptor(uint16_t* len){ if(len)*len=sizeof(SYSTEM_RD); return SYSTEM_RD; }
void EvilCrowConsumer::begin(){ uint16_t l; auto rd=reportDescriptor(&l); EclHidFragment f{rd,l,false}; Usb.enableHid(f); }
void EvilCrowConsumer::press(uint16_t u){ uint8_t r[2]={(uint8_t)(u&0xFF),(uint8_t)(u>>8)}; Usb.hidSendReport(ECL_RID_CONSUMER,r,2); }
void EvilCrowConsumer::release(){ uint8_t r[2]={0,0}; Usb.hidSendReport(ECL_RID_CONSUMER,r,2); }
void EvilCrowSystem::begin(){ uint16_t l; auto rd=reportDescriptor(&l); EclHidFragment f{rd,l,false}; Usb.enableHid(f); }
void EvilCrowSystem::press(uint8_t u){ Usb.hidSendReport(ECL_RID_SYSTEM,&u,1); }
void EvilCrowSystem::release(){ uint8_t z=0; Usb.hidSendReport(ECL_RID_SYSTEM,&z,1); }
