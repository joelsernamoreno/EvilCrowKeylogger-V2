#include "soc/soc_caps.h"

#if defined(SOC_USB_OTG_SUPPORTED) && SOC_USB_OTG_SUPPORTED && __has_include("tusb.h")

#include "tusb.h"
#include "class/net/net_device.h"
#include "device/usbd_pvt.h"

#undef CFG_TUD_NCM
#undef CFG_TUD_ECM_RNDIS
#define CFG_TUD_NCM 0
#define CFG_TUD_ECM_RNDIS 1

#define netd_init                    ecl_ecm_netd_init
#define netd_deinit                  ecl_ecm_netd_deinit
#define netd_reset                   ecl_ecm_netd_reset
#define netd_open                    ecl_ecm_netd_open
#define netd_control_xfer_cb         ecl_ecm_netd_control_xfer_cb
#define netd_xfer_cb                 ecl_ecm_netd_xfer_cb
#define netd_report                  ecl_ecm_netd_report
#define tud_network_recv_renew       ecl_ecm_network_recv_renew
#define tud_network_can_xmit         ecl_ecm_network_can_xmit
#define tud_network_xmit             ecl_ecm_network_xmit
#define tud_network_link_state       ecl_ecm_network_link_state

#ifndef CFG_TUD_NET_ENDPOINT_SIZE
#define CFG_TUD_NET_ENDPOINT_SIZE (TUD_OPT_HIGH_SPEED ? 512 : 64)
#endif

#if TUSB_VERSION_NUMBER >= 2100
#define usbd_edpt_xfer(_rhport, _ep, _buf, _len) \
        usbd_edpt_xfer((_rhport), (_ep), (_buf), (_len), false)
#define ECL_UNDEF_USBD_EDPT_XFER 1
#endif

#include "ecl_tinyusb/ecm_rndis_device_2025.inc"
#include "ecl_tinyusb/rndis_reports_2025.inc"

#if defined(ECL_UNDEF_USBD_EDPT_XFER)
#undef usbd_edpt_xfer
#undef ECL_UNDEF_USBD_EDPT_XFER
#endif

#endif
