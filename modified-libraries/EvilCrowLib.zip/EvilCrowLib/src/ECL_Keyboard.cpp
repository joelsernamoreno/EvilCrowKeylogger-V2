/*
 * EvilCrowLib - ECL_Keyboard.cpp
 */
#include "ECL_Keyboard.h"
#include "ecl_layouts.h"

// ---- HID report descriptors -------------------------------------------------
// 6KRO boot-compatible keyboard (report id ECL_RID_KEYBOARD).
static const uint8_t KBD_6KRO[] = {
  0x05,0x01, 0x09,0x06, 0xA1,0x01,
    0x85,ECL_RID_KEYBOARD,
    0x05,0x07, 0x19,0xE0, 0x29,0xE7, 0x15,0x00, 0x25,0x01, 0x75,0x01, 0x95,0x08, 0x81,0x02, // modifiers
    0x95,0x01, 0x75,0x08, 0x81,0x03,                                                        // reserved
    0x05,0x08, 0x19,0x01, 0x29,0x05, 0x95,0x05, 0x75,0x01, 0x91,0x02,                        // LED out
    0x95,0x01, 0x75,0x03, 0x91,0x03,                                                         // LED pad
    0x05,0x07, 0x19,0x00, 0x2A,0xFF,0x00, 0x15,0x00, 0x26,0xFF,0x00, 0x95,0x06, 0x75,0x08, 0x81,0x00, // 6 keys
  0xC0
};

// NKRO keyboard: modifier byte + bitmap of usages 0x00..0x7F (report id ECL_RID_KEYBOARD).
static const uint8_t KBD_NKRO[] = {
  0x05,0x01, 0x09,0x06, 0xA1,0x01,
    0x85,ECL_RID_KEYBOARD,
    0x05,0x07, 0x19,0xE0, 0x29,0xE7, 0x15,0x00, 0x25,0x01, 0x75,0x01, 0x95,0x08, 0x81,0x02, // modifiers
    0x05,0x08, 0x19,0x01, 0x29,0x05, 0x95,0x05, 0x75,0x01, 0x91,0x02,                        // LED out
    0x95,0x01, 0x75,0x03, 0x91,0x03,                                                         // LED pad
    0x05,0x07, 0x19,0x00, 0x29,0x7F, 0x15,0x00, 0x25,0x01, 0x75,0x01, 0x95,0x80, 0x81,0x02,  // 128-bit bitmap
  0xC0
};

const uint8_t* EvilCrowKeyboard::reportDescriptor(uint16_t* len, bool nkro) {
  if (nkro) { if (len) *len = sizeof(KBD_NKRO); return KBD_NKRO; }
  if (len) *len = sizeof(KBD_6KRO); 
    return KBD_6KRO;
}

static EvilCrowKeyboard* s_activeKbd = nullptr;
void ecl_keyboard_led_bridge(uint8_t leds) {
  if (s_activeKbd && s_activeKbd->_ledFn) {
    ecl_keyboard_leds_t l; l.leds = leds;
    s_activeKbd->_ledFn(l);
  }
}

EvilCrowKeyboard::EvilCrowKeyboard() : _layout(en_us) {
  memset(&_report, 0, sizeof(_report));
  memset(_nkroBitmap, 0, sizeof(_nkroBitmap));
}

void EvilCrowKeyboard::begin() {
  if (_began) return;
  uint16_t rlen; const uint8_t* rd = reportDescriptor(&rlen, _nkro);
  EclHidFragment frag { rd, rlen, true };
  Usb.enableHid(frag);
  s_activeKbd = this;
  Usb.onKeyboardLeds([](uint8_t leds){ ecl_keyboard_led_bridge(leds); });
  _began = true;
}
void EvilCrowKeyboard::end() { _began = false; }

static uint8_t asciiToUsage(const uint8_t* layout, uint8_t c, bool* shift, bool* altgr) {
  *shift = false; *altgr = false;
  if (c >= 0x88) { /* modifiers handled separately */ return 0; }
  uint8_t v = (c < 128) ? layout[c] : 0;
  if (v == 0) return 0;

  if (v & 0x80) { *shift = true; v &= 0x7F; }
  if (v == 0x64) return v;
  if (v & 0x40) { *altgr = true; v &= 0x3F; }
  return v;
}

// Non-printing Arduino KEY_* -> HID usage.
static uint8_t specialUsage(uint8_t k) {
  switch (k) {
    case KEY_RETURN: return 0x28; case KEY_ESC: return 0x29; case KEY_BACKSPACE: return 0x2A;
    case KEY_TAB: return 0x2B; case KEY_SPACE: return 0x2C; case KEY_CAPS_LOCK: return 0x39;
    case KEY_F1: return 0x3A; case KEY_F2: return 0x3B; case KEY_F3: return 0x3C; case KEY_F4: return 0x3D;
    case KEY_F5: return 0x3E; case KEY_F6: return 0x3F; case KEY_F7: return 0x40; case KEY_F8: return 0x41;
    case KEY_F9: return 0x42; case KEY_F10: return 0x43; case KEY_F11: return 0x44; case KEY_F12: return 0x45;
    case KEY_PRINT_SCREEN: return 0x46; case KEY_SCROLL_LOCK: return 0x47; case KEY_PAUSE: return 0x48;
    case KEY_INSERT: return 0x49; case KEY_HOME: return 0x4A; case KEY_PAGE_UP: return 0x4B;
    case KEY_DELETE: return 0x4C; case KEY_END: return 0x4D; case KEY_PAGE_DOWN: return 0x4E;
    case KEY_RIGHT_ARROW: return 0x4F; case KEY_LEFT_ARROW: return 0x50; case KEY_DOWN_ARROW: return 0x51;
    case KEY_UP_ARROW: return 0x52; case KEY_NUM_LOCK: return 0x53; case KEY_MENU: return 0x65;
    case KEY_KP_SLASH: return 0x54; case KEY_KP_ASTERISK: return 0x55; case KEY_KP_MINUS: return 0x56;
    case KEY_KP_PLUS: return 0x57; case KEY_KP_ENTER: return 0x58;
    case KEY_KP_1: return 0x59; case KEY_KP_2: return 0x5A; case KEY_KP_3: return 0x5B;
    case KEY_KP_4: return 0x5C; case KEY_KP_5: return 0x5D; case KEY_KP_6: return 0x5E;
    case KEY_KP_7: return 0x5F; case KEY_KP_8: return 0x60; case KEY_KP_9: return 0x61;
    case KEY_KP_0: return 0x62; case KEY_KP_DOT: return 0x63;
    default: return 0;
  }
}

static uint8_t modifierBit(uint8_t k) {
  switch (k) {
    case KEY_LEFT_CTRL: return 0x01; case KEY_LEFT_SHIFT: return 0x02;
    case KEY_LEFT_ALT: return 0x04;  case KEY_LEFT_GUI: return 0x08;
    case KEY_RIGHT_CTRL: return 0x10; case KEY_RIGHT_SHIFT: return 0x20;
    case KEY_RIGHT_ALT: return 0x40;  case KEY_RIGHT_GUI: return 0x80;
    default: return 0;
  }
}

void EvilCrowKeyboard::sendCurrent() {
  if (_nkro) {
    uint8_t buf[17]; buf[0] = _report.modifiers;
    memcpy(buf+1, _nkroBitmap, 16);
    Usb.hidSendReport(ECL_RID_KEYBOARD, buf, sizeof(buf));
  } else {
    Usb.hidSendReport(ECL_RID_KEYBOARD, ((uint8_t*)&_report), sizeof(_report));
  }
}

size_t EvilCrowKeyboard::press(uint8_t k) {
  uint8_t mb = modifierBit(k);
  if (mb) { _report.modifiers |= mb; sendCurrent(); return 1; }

  bool shift=false, altgr=false; uint8_t usage = specialUsage(k);
  if (!usage) usage = asciiToUsage(_layout, k, &shift, &altgr);
  if (!usage) return 0;
  if (shift) _report.modifiers |= 0x02;
  if (altgr) _report.modifiers |= 0x40;

  if (_nkro) {
    _nkroBitmap[usage >> 3] |= (1 << (usage & 7));
  } else {
    for (int i=0;i<6;i++) if (_report.keys[i]==usage) { sendCurrent(); return 1; }
    for (int i=0;i<6;i++) if (_report.keys[i]==0) { _report.keys[i]=usage; break; }
  }
  sendCurrent();
  return 1;
}

size_t EvilCrowKeyboard::release(uint8_t k) {
  uint8_t mb = modifierBit(k);
  if (mb) { _report.modifiers &= ~mb; sendCurrent(); return 1; }
  bool shift=false, altgr=false; uint8_t usage = specialUsage(k);
  if (!usage) usage = asciiToUsage(_layout, k, &shift, &altgr);
  if (!usage) return 0;
  if (shift) _report.modifiers &= ~0x02;
  if (altgr) _report.modifiers &= ~0x40;
  if (_nkro) _nkroBitmap[usage >> 3] &= ~(1 << (usage & 7));
  else for (int i=0;i<6;i++) if (_report.keys[i]==usage) _report.keys[i]=0;
  sendCurrent();
  return 1;
}

size_t EvilCrowKeyboard::pressRaw(uint8_t usage) {
  if (_nkro) _nkroBitmap[usage>>3] |= (1<<(usage&7));
  else for (int i=0;i<6;i++) if (_report.keys[i]==0) { _report.keys[i]=usage; break; }
  sendCurrent(); return 1;
}
size_t EvilCrowKeyboard::releaseRaw(uint8_t usage) {
  if (_nkro) _nkroBitmap[usage>>3] &= ~(1<<(usage&7));
  else for (int i=0;i<6;i++) if (_report.keys[i]==usage) _report.keys[i]=0;
  sendCurrent(); return 1;
}

void EvilCrowKeyboard::releaseAll() {
  memset(&_report, 0, sizeof(_report));
  memset(_nkroBitmap, 0, sizeof(_nkroBitmap));
  sendCurrent();
}

void EvilCrowKeyboard::sendReport(EclKeyReport* keys) {
  _report = *keys; sendCurrent();
}

size_t EvilCrowKeyboard::write(uint8_t c) {
  press(c); delay(1); release(c); return 1;
}
size_t EvilCrowKeyboard::write(const uint8_t* buffer, size_t size) {
  size_t n=0; while (size--) { if (write(*buffer++)) n++; }
  return n;
}
