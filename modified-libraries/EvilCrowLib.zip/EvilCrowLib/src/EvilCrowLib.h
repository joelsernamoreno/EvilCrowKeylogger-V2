#pragma once

#include "ECL_Usb.h"
#include "ecl_keys.h"
#include "ecl_layouts.h"
#include "ECL_Keyboard.h"
#include "ECL_Mouse.h"
#include "ECL_Media.h"
#include "ECL_CustomHID.h"
#include "ECL_Msc.h"
#include "ECL_Net.h"

extern EvilCrowKeyboard Keyboard;
extern EvilCrowMouse    Mouse;
extern EvilCrowConsumer Consumer;
extern EvilCrowSystem   SystemCtl;

#define EVILCROWLIB_VERSION "1.0.8"
