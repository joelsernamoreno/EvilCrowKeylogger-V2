#include "ECL_NetDriver.h"
#include "soc/soc_caps.h"
#include <string.h>

#define ECL_DRIVER_MODE_NCM   1U
#define ECL_DRIVER_MODE_ECM   2U
#define ECL_DRIVER_MODE_RNDIS 3U

#if defined(SOC_USB_OTG_SUPPORTED) && SOC_USB_OTG_SUPPORTED && __has_include("tusb.h")

#include "tusb.h"
#include "class/net/net_device.h"

#if (defined(CFG_TUD_NCM) && CFG_TUD_NCM) || \
    (defined(CFG_TUD_ECM_RNDIS) && CFG_TUD_ECM_RNDIS)
#define ECL_CORE_HAS_NET_SLOT 1
#else
#define ECL_CORE_HAS_NET_SLOT 0
#endif

// Namespaced CDC-NCM backend.
void     ecl_ncm_netd_init(void);
bool     ecl_ncm_netd_deinit(void);
void     ecl_ncm_netd_reset(uint8_t rhport);
uint16_t ecl_ncm_netd_open(uint8_t rhport, tusb_desc_interface_t const*, uint16_t);
bool     ecl_ncm_netd_control_xfer_cb(uint8_t, uint8_t, tusb_control_request_t const*);
bool     ecl_ncm_netd_xfer_cb(uint8_t, uint8_t, xfer_result_t, uint32_t);
void     ecl_ncm_network_recv_renew(void);
bool     ecl_ncm_network_can_xmit(uint16_t size);
void     ecl_ncm_network_xmit(void* ref, uint16_t arg);
void     ecl_ncm_network_link_state(uint8_t rhport, bool up);
void     ecl_ncm_tx_watchdog(uint32_t now_ms);

// Namespaced CDC-ECM/RNDIS backend.
void     ecl_ecm_netd_init(void);
bool     ecl_ecm_netd_deinit(void);
void     ecl_ecm_netd_reset(uint8_t rhport);
uint16_t ecl_ecm_netd_open(uint8_t rhport, tusb_desc_interface_t const*, uint16_t);
bool     ecl_ecm_netd_control_xfer_cb(uint8_t, uint8_t, tusb_control_request_t const*);
bool     ecl_ecm_netd_xfer_cb(uint8_t, uint8_t, xfer_result_t, uint32_t);
void     ecl_ecm_netd_report(uint8_t* buf, uint16_t len);
void     ecl_ecm_network_recv_renew(void);
bool     ecl_ecm_network_can_xmit(uint16_t size);
void     ecl_ecm_network_xmit(void* ref, uint16_t arg);
void     ecl_ecm_network_link_state(uint8_t rhport, bool up);

static uint8_t s_eclNetMode = ECL_DRIVER_MODE_NCM;

static bool eclUseNcm(void) { return s_eclNetMode == ECL_DRIVER_MODE_NCM; }

bool ecl_net_driver_supports(uint8_t mode) {
  if (!ECL_CORE_HAS_NET_SLOT) return false;
  return mode == ECL_DRIVER_MODE_NCM || mode == ECL_DRIVER_MODE_ECM ||
         mode == ECL_DRIVER_MODE_RNDIS;
}

void ecl_net_driver_select(uint8_t mode) {
  if (ecl_net_driver_supports(mode)) s_eclNetMode = mode;
}

void ecl_net_driver_watchdog(uint32_t now_ms) {
  if (eclUseNcm()) ecl_ncm_tx_watchdog(now_ms);
}

void ecl_net_driver_diag(ecl_ncm_diag_t* out) {
  if (out == NULL) return;
  memset(out, 0, sizeof(*out));
  if (eclUseNcm()) ecl_ncm_get_diag(out);
}

void netd_init(void) {
  if (eclUseNcm()) ecl_ncm_netd_init(); else ecl_ecm_netd_init();
}

bool netd_deinit(void) {
  return eclUseNcm() ? ecl_ncm_netd_deinit() : ecl_ecm_netd_deinit();
}

void netd_reset(uint8_t rhport) {
  if (eclUseNcm()) ecl_ncm_netd_reset(rhport); else ecl_ecm_netd_reset(rhport);
  ecl_net_driver_event();
}

uint16_t netd_open(uint8_t rhport, tusb_desc_interface_t const* itf, uint16_t maxLen) {
  return eclUseNcm() ? ecl_ncm_netd_open(rhport, itf, maxLen)
                     : ecl_ecm_netd_open(rhport, itf, maxLen);
}

bool netd_control_xfer_cb(uint8_t rhport, uint8_t stage,
                          tusb_control_request_t const* request) {
  bool handled = eclUseNcm() ? ecl_ncm_netd_control_xfer_cb(rhport, stage, request)
                             : ecl_ecm_netd_control_xfer_cb(rhport, stage, request);
  if (handled) ecl_net_driver_event();
  return handled;
}

bool netd_xfer_cb(uint8_t rhport, uint8_t ep, xfer_result_t result, uint32_t len) {
  bool handled = eclUseNcm() ? ecl_ncm_netd_xfer_cb(rhport, ep, result, len)
                             : ecl_ecm_netd_xfer_cb(rhport, ep, result, len);
  if (handled) ecl_net_driver_event();
  return handled;
}

void netd_report(uint8_t* buf, uint16_t len) {
  if (!eclUseNcm()) ecl_ecm_netd_report(buf, len);
}

void tud_network_recv_renew(void) {
  if (eclUseNcm()) ecl_ncm_network_recv_renew(); else ecl_ecm_network_recv_renew();
}

bool tud_network_can_xmit(uint16_t size) {
  return eclUseNcm() ? ecl_ncm_network_can_xmit(size)
                     : ecl_ecm_network_can_xmit(size);
}

void tud_network_xmit(void* ref, uint16_t arg) {
  if (eclUseNcm()) ecl_ncm_network_xmit(ref, arg); else ecl_ecm_network_xmit(ref, arg);
}

void tud_network_link_state(uint8_t rhport, bool up) {
  if (eclUseNcm()) ecl_ncm_network_link_state(rhport, up);
  else ecl_ecm_network_link_state(rhport, up);
}

#else

bool ecl_net_driver_supports(uint8_t mode) { (void)mode; return false; }
void ecl_net_driver_select(uint8_t mode) { (void)mode; }
void ecl_net_driver_watchdog(uint32_t now_ms) { (void)now_ms; }
void ecl_net_driver_diag(ecl_ncm_diag_t* out) {
  if (out != NULL) memset(out, 0, sizeof(*out));
}

#endif
