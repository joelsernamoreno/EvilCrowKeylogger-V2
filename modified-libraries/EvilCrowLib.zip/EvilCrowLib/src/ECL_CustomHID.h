/* EvilCrowLib - ECL_CustomHID.h
 * RawHID  : fixed 64-byte vendor IN/OUT report pair for host<->device pipes.
 * CustomHID: caller supplies its own HID report-descriptor fragment.
 */
#pragma once
#include <Arduino.h>
#include <functional>
#include "ECL_Usb.h"

class EvilCrowRawHID {
public:
  void begin();
  bool send(const uint8_t* data, uint16_t len);           // len<=64
  void onReceive(std::function<void(const uint8_t*,uint16_t)> cb);
  static const uint8_t* reportDescriptor(uint16_t* len);
};

class EvilCrowCustomHID {
public:
  void begin(const uint8_t* desc, uint16_t len);
  bool send(const uint8_t* data, uint16_t len);
  void onReceive(std::function<void(const uint8_t*,uint16_t)> cb);
};
