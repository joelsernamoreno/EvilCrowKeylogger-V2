#pragma once
#include <Arduino.h>
#include "ECL_Usb.h"

// Common consumer usages
#define CC_VOLUME_UP     0x00E9
#define CC_VOLUME_DOWN   0x00EA
#define CC_MUTE          0x00E2
#define CC_PLAY_PAUSE    0x00CD
#define CC_NEXT_TRACK    0x00B5
#define CC_PREV_TRACK    0x00B6
#define CC_STOP          0x00B7
#define CC_BRIGHT_UP     0x006F
#define CC_BRIGHT_DOWN   0x0070
// System usages
#define SYS_POWER_DOWN   0x81
#define SYS_SLEEP        0x82
#define SYS_WAKE_UP      0x83

class EvilCrowConsumer {
public:
  void begin();
  void press(uint16_t usage);
  void release();
  void tap(uint16_t usage) { press(usage); delay(10); release(); }
  static const uint8_t* reportDescriptor(uint16_t* len);
};

class EvilCrowSystem {
public:
  void begin();
  void press(uint8_t usage);
  void release();
  void tap(uint8_t usage) { press(usage); delay(10); release(); }
  static const uint8_t* reportDescriptor(uint16_t* len);
};
