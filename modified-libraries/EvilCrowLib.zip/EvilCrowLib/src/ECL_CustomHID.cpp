#include "ECL_CustomHID.h"
static const uint8_t RAW_RD[] = {
  0x06,0x00,0xFF, 0x09,0x01, 0xA1,0x01, 0x85,ECL_RID_RAW,
    0x15,0x00, 0x26,0xFF,0x00, 0x75,0x08, 0x95,0x40, 0x09,0x01, 0x81,0x02,
    0x95,0x40, 0x09,0x01, 0x91,0x02,
  0xC0
};
const uint8_t* EvilCrowRawHID::reportDescriptor(uint16_t* len){ if(len)*len=sizeof(RAW_RD); return RAW_RD; }
void EvilCrowRawHID::begin(){ uint16_t l; auto rd=reportDescriptor(&l); EclHidFragment f{rd,l,true}; Usb.enableHid(f); }
bool EvilCrowRawHID::send(const uint8_t* d,uint16_t n){ uint8_t b[64]={0}; memcpy(b,d,n>64?64:n); return Usb.hidSendReport(ECL_RID_RAW,b,64); }
void EvilCrowRawHID::onReceive(std::function<void(const uint8_t*,uint16_t)> cb){ Usb.onRawHid(cb); }
void EvilCrowCustomHID::begin(const uint8_t* desc,uint16_t len){ EclHidFragment f{desc,len,true}; Usb.enableHid(f); }
bool EvilCrowCustomHID::send(const uint8_t* d,uint16_t n){ return Usb.hidSendReport(ECL_RID_CUSTOM,d,n); }
void EvilCrowCustomHID::onReceive(std::function<void(const uint8_t*,uint16_t)> cb){ Usb.onRawHid(cb); }
