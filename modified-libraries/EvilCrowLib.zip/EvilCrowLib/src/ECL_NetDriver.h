#pragma once
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

bool ecl_net_driver_supports(uint8_t mode);
void ecl_net_driver_select(uint8_t mode);
void ecl_net_driver_event(void);
void ecl_net_driver_watchdog(uint32_t now_ms);

typedef struct {
  uint32_t completions;
  uint32_t canXmitFail;
  uint32_t softRecover;
  uint32_t hardRecover;
  uint8_t  inFlight;
  uint8_t  readyCount;
  uint8_t  freeCount;
  uint8_t  epInBusy;
} ecl_ncm_diag_t;

void ecl_ncm_get_diag(ecl_ncm_diag_t* out);
void ecl_net_driver_diag(ecl_ncm_diag_t* out);
void ecl_usbd_edpt_force_idle(uint8_t rhport, uint8_t ep_addr);

#ifdef __cplusplus
}
#endif
