#include "ECL_Net.h"
#include "ECL_NetDriver.h"
#include "ECL_Usb.h"

#if defined(SOC_USB_OTG_SUPPORTED) && SOC_USB_OTG_SUPPORTED && __has_include("esp32-hal-tinyusb.h")
  #include "tusb.h"
  #include "device/usbd_pvt.h"
  #define ECL_NET_HAL 1
#else
  #define ECL_NET_HAL 0
#endif

#include "esp_netif.h"
#include "esp_event.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#if __has_include("esp_netif_net_stack.h")
  #include "esp_netif_net_stack.h"
  #include "lwip/netif.h"
  #define ECL_HAS_NETSTACK 1
#else
  #define ECL_HAS_NETSTACK 0
#endif

#if ECL_HAS_NETSTACK && __has_include("lwip/esp_netif_net_stack.h")
  #include "lwip/esp_netif_net_stack.h"
  #include "lwip/pbuf.h"
  #define ECL_HAS_COPY_INPUT 1
#else
  #define ECL_HAS_COPY_INPUT 0
#endif

#ifndef CFG_TUD_NET_MTU
#define CFG_TUD_NET_MTU 1514
#endif

EvilCrowUsbNet UsbNet;

uint8_t tud_network_mac_address[6] = {0x02, 0x50, 0xCA, 0xDE, 0x00, 0x01};

static esp_netif_t*            s_netif      = nullptr;
static esp_netif_driver_base_t s_driverBase = {};
static esp_netif_ip_info_t     s_ipInfo     = {};
static bool                    s_started    = false;
static bool                    s_naptEnabled = false;
static bool                    s_rawBridge  = false;
static EclNetRawRxCallback     s_rawReceive = nullptr;
static void*                   s_rawReceiveContext = nullptr;
static volatile bool           s_rawCarrier = false;
static uint8_t                 s_devMac[6]  = {0};
static volatile bool           s_linkUp     = false;
static bool                    s_linkStateApplied = false;
static uint32_t                s_txSent     = 0;
static uint32_t                s_txDropped  = 0;
static uint32_t                s_txStalled  = 0;
static uint32_t                s_rxFrames   = 0;
static uint32_t                s_rxDropped  = 0;
static portMUX_TYPE            s_statsMux   = portMUX_INITIALIZER_UNLOCKED;

static void eclStatInc(uint32_t& counter) {
  portENTER_CRITICAL(&s_statsMux);
  ++counter;
  portEXIT_CRITICAL(&s_statsMux);
}

static uint32_t eclStatRead(const uint32_t& counter) {
  portENTER_CRITICAL(&s_statsMux);
  const uint32_t value = counter;
  portEXIT_CRITICAL(&s_statsMux);
  return value;
}

static void eclStatsReset() {
  portENTER_CRITICAL(&s_statsMux);
  s_txSent = 0;
  s_txDropped = 0;
  s_txStalled = 0;
  s_rxFrames = 0;
  s_rxDropped = 0;
  portEXIT_CRITICAL(&s_statsMux);
}

static volatile bool     s_snatOn     = false;
static uint32_t          s_snatDevIp  = 0;   // 192.168.7.1 (octet 0 in low byte)
static uint32_t          s_snatTgtIp  = 0;   // 192.168.7.2
static volatile uint32_t s_snatOperIp = 0;   // learned operator addr, 0 = none

static inline uint16_t eclRd16(const uint8_t* p) { return (uint16_t)((p[0] << 8) | p[1]); }
static inline void     eclWr16(uint8_t* p, uint16_t v) { p[0] = (uint8_t)(v >> 8); p[1] = (uint8_t)v; }

static uint16_t eclCsumReplace(uint16_t oldCk, const uint8_t* oldW,
                               const uint8_t* newW, int nWords) {
  uint32_t sum = (uint16_t)~oldCk;
  for (int i = 0; i < nWords; ++i) {
    sum += (uint16_t)~eclRd16(oldW + 2 * i);
    sum += eclRd16(newW + 2 * i);
  }
  while (sum >> 16) sum = (sum & 0xffff) + (sum >> 16);
  return (uint16_t)~sum;
}

static bool eclIpv4ReplaceAddr(uint8_t* f, uint16_t len, bool isSrc, uint32_t newIp) {
  if (!f || len < 14 + 20) return false;
  if (eclRd16(f + 12) != 0x0800) return false;         // not IPv4 (no VLAN tag)
  uint8_t* ip = f + 14;
  if ((ip[0] >> 4) != 4) return false;
  const uint16_t ihl = (uint16_t)(ip[0] & 0x0f) * 4u;
  if (ihl < 20 || (uint16_t)(14 + ihl) > len) return false;

  uint8_t* addr = ip + (isSrc ? 12 : 16);
  uint8_t newW[4]; memcpy(newW, &newIp, 4);
  if (memcmp(addr, newW, 4) == 0) return true;
  uint8_t oldW[4]; memcpy(oldW, addr, 4);

  eclWr16(ip + 10, eclCsumReplace(eclRd16(ip + 10), oldW, newW, 2));

  const uint16_t frag  = eclRd16(ip + 6) & 0x1fff;     // only fragment 0 has L4
  const uint8_t  proto = ip[9];
  uint8_t* l4 = ip + ihl;
  const uint16_t l4len = (uint16_t)(len - 14 - ihl);
  if (frag == 0) {
    if (proto == 6 && l4len >= 18) {                   // TCP checksum
      eclWr16(l4 + 16, eclCsumReplace(eclRd16(l4 + 16), oldW, newW, 2));
    } else if (proto == 17 && l4len >= 8) {            // UDP checksum
      uint16_t ck = eclRd16(l4 + 6);
      if (ck != 0) {                                   // 0 = checksum not used
        ck = eclCsumReplace(ck, oldW, newW, 2);
        if (ck == 0) ck = 0xffff;                      // 0 is reserved for UDP
        eclWr16(l4 + 6, ck);
      }
    }
  }
  memcpy(addr, newW, 4);
  return true;
}

static inline bool eclOnUsbSubnet(uint32_t ip) {
  return (ip & 0x00FFFFFFu) == (s_snatDevIp & 0x00FFFFFFu);
}

static void eclSnatOutbound(uint8_t* f, uint16_t len) {
  if (!s_snatOn || !f || len < 14 + 20 || eclRd16(f + 12) != 0x0800) return;
  const uint8_t* ip = f + 14;
  uint32_t src, dst; memcpy(&src, ip + 12, 4); memcpy(&dst, ip + 16, 4);
  if (dst != s_snatTgtIp) return;                      // only traffic to target
  if (eclOnUsbSubnet(src)) return;                     // device/link-local: leave
  s_snatOperIp = src;                                  // atomic 32-bit store
  eclIpv4ReplaceAddr(f, len, true, s_snatDevIp);       // src -> 192.168.7.1
}

static void eclSnatInbound(uint8_t* f, uint16_t len) {
  const uint32_t oper = s_snatOperIp;
  if (!s_snatOn || oper == 0 || !f || len < 14 + 20 || eclRd16(f + 12) != 0x0800) return;
  const uint8_t* ip = f + 14;
  uint32_t src, dst; memcpy(&src, ip + 12, 4); memcpy(&dst, ip + 16, 4);
  if (src != s_snatTgtIp || dst != s_snatDevIp) return;
  const uint16_t ihl = (uint16_t)(ip[0] & 0x0f) * 4u;
  if (ip[9] == 17 && (uint16_t)(14 + ihl + 8) <= len) {
    const uint8_t* udp = f + 14 + ihl;
    const uint16_t sp = eclRd16(udp), dp = eclRd16(udp + 2);
    if (sp == 67 || sp == 68 || dp == 67 || dp == 68) return;
  }
  eclIpv4ReplaceAddr(f, len, false, oper);
}

#define ECL_TX_SLOTS          24
#define ECL_FRAME_SIZE        1600
#define ECL_TX_MAX_AGE_MS     3000U
#define ECL_TX_STALL_MS       2000U
#define ECL_TX_BURST          32

struct EclTxSlot {
  uint16_t len;
  uint32_t queuedAt;
  bool priority;
  uint8_t data[ECL_FRAME_SIZE];
};

static EclTxSlot*    s_txSlots     = nullptr;
static QueueHandle_t s_txPriorityQ = nullptr;
static QueueHandle_t s_txDataQ     = nullptr;
static QueueHandle_t s_txFreeQ     = nullptr;

struct EclRawTxPacket {
  const uint8_t* data;
  uint16_t len;
  bool accepted;
};

static SemaphoreHandle_t       s_rawCallMutex = nullptr;
static SemaphoreHandle_t       s_rawAccess    = nullptr;
static SemaphoreHandle_t       s_rawDone      = nullptr;
static EclRawTxPacket* volatile s_rawPacket   = nullptr;
static volatile bool           s_rawSendPending = false;
static volatile bool s_txPending      = false;
static uint8_t       s_txPendingIndex = 0;
static uint32_t      s_txPendingSince = 0;
static volatile bool s_serviceScheduled = false;
static portMUX_TYPE  s_serviceMux = portMUX_INITIALIZER_UNLOCKED;
static uint32_t      s_serviceScheduledAt = 0;
static uint32_t      s_lastRecoveryKick = 0;

static bool eclPriorityFrame(const uint8_t* data, uint16_t len) {
  if (!data || len < 14) return false;
  const uint16_t etherType = ((uint16_t)data[12] << 8) | data[13];
  if (etherType == 0x0806) return true;                         // ARP
  if (etherType == 0x86DD && len >= 54 && data[20] == 58) return true; // ICMPv6
  if (etherType != 0x0800 || len < 34) return false;

  const uint8_t protocol = data[23];
  if (protocol == 1) return true;                               // ICMPv4
  if (protocol != 17) return false;
  const uint16_t ihl = (uint16_t)(data[14] & 0x0f) * 4U;
  if (ihl < 20 || len < 14U + ihl + 8U) return false;
  const uint8_t* udp = data + 14U + ihl;
  const uint16_t srcPort = ((uint16_t)udp[0] << 8) | udp[1];
  const uint16_t dstPort = ((uint16_t)udp[2] << 8) | udp[3];
  return srcPort == 53 || dstPort == 53 ||
         srcPort == 67 || dstPort == 67 || srcPort == 68 || dstPort == 68;
}

static void eclUsbNetServiceDeferred(void*);

static void eclScheduleUsbService() {
#if ECL_NET_HAL
  if (!s_started || !tud_inited()) return;

  uint32_t const now = millis();
  bool enqueue = false;
  portENTER_CRITICAL(&s_serviceMux);
  if (!s_serviceScheduled) {
    s_serviceScheduled = true;
    s_serviceScheduledAt = now;
    enqueue = true;
  }
  portEXIT_CRITICAL(&s_serviceMux);

  if (enqueue) {
    usbd_defer_func(eclUsbNetServiceDeferred, nullptr, false);
  }
#endif
}

static bool eclTxWorkWaiting() {
#if ECL_NET_HAL
  if (s_rawBridge && s_linkUp != (s_rawCarrier && tud_mounted())) return true;
  return s_rawSendPending || s_txPending ||
         (s_txPriorityQ && uxQueueMessagesWaiting(s_txPriorityQ) != 0) ||
         (s_txDataQ && uxQueueMessagesWaiting(s_txDataQ) != 0);
#else
  return false;
#endif
}

static bool eclNetTxFrame(const uint8_t* data, uint16_t len) {
#if ECL_NET_HAL
  if (!data || len == 0 || len > ECL_FRAME_SIZE) return false;
  if (!s_txPriorityQ || !s_txDataQ || !s_txFreeQ) return false;

  const bool priority = eclPriorityFrame(data, len);

  uint8_t idx;
  if (xQueueReceive(s_txFreeQ, &idx, 0) != pdTRUE) {
    if (!priority || xQueueReceive(s_txDataQ, &idx, 0) != pdTRUE) {
      eclStatInc(s_txDropped);
      return false;
    }
    eclStatInc(s_txDropped);
  }

  EclTxSlot& slot = s_txSlots[idx];
  slot.len = len;
  slot.queuedAt = millis();
  slot.priority = priority;
  memcpy(slot.data, data, len);
  eclSnatOutbound(slot.data, len);

  QueueHandle_t target = priority ? s_txPriorityQ : s_txDataQ;
  if (xQueueSend(target, &idx, 0) != pdTRUE) {
    xQueueSend(s_txFreeQ, &idx, 0);
    eclStatInc(s_txDropped);
    return false;
  }
  eclScheduleUsbService();
  return true;
#else
  (void)data; (void)len; return false;
#endif
}

#if ECL_NET_HAL
static void eclTxReturn(uint8_t idx) {
  if (s_txFreeQ) xQueueSend(s_txFreeQ, &idx, 0);
}

static void eclFlushTx() {
  if (s_txPending) {
    eclTxReturn(s_txPendingIndex);
    s_txPending = false;
  }
  uint8_t idx;
  if (s_txPriorityQ) {
    while (xQueueReceive(s_txPriorityQ, &idx, 0) == pdTRUE) eclTxReturn(idx);
  }
  if (s_txDataQ) {
    while (xQueueReceive(s_txDataQ, &idx, 0) == pdTRUE) eclTxReturn(idx);
  }
}

static void eclRawTxService(bool linkReady) {
  if (!s_rawSendPending || !s_rawAccess || !s_rawDone) return;
  if (xSemaphoreTake(s_rawAccess, 0) != pdTRUE) return;

  EclRawTxPacket* packet = s_rawPacket;
  bool finished = false;
  if (packet) {
    if (!linkReady) {
      packet->accepted = false;
      s_rawPacket = nullptr;
      s_rawSendPending = false;
      eclStatInc(s_txDropped);
      finished = true;
    } else if (tud_network_can_xmit(packet->len)) {
      tud_network_xmit((void*)packet->data, packet->len);
      packet->accepted = true;
      s_rawPacket = nullptr;
      s_rawSendPending = false;
      eclStatInc(s_txSent);
      finished = true;
    }
  } else {
    s_rawSendPending = false;
  }

  xSemaphoreGive(s_rawAccess);
  if (finished) xSemaphoreGive(s_rawDone);
}

static void eclUsbNetService() {
  if (!s_started) return;

  const bool mounted = tud_mounted();
  const bool desiredLink = mounted && (!s_rawBridge || s_rawCarrier);
  if (!mounted) {
    const bool wasUp = s_linkUp;
    s_linkUp = false;
    s_linkStateApplied = false;
    if (wasUp && !s_rawBridge) eclFlushTx();
  }
  if (mounted && (!s_linkStateApplied || desiredLink != s_linkUp)) {
    s_linkUp = desiredLink;
    tud_network_link_state(0, desiredLink);
    s_linkStateApplied = true;
    if (!desiredLink && !s_rawBridge) eclFlushTx();
  }

  if (s_rawBridge) {
    eclRawTxService(desiredLink);
    return;
  }

  {
    static uint32_t s_lastWatchdog = 0;
    const uint32_t now = millis();
    if (now - s_lastWatchdog >= 50U) {
      s_lastWatchdog = now;
      ecl_net_driver_watchdog(now);
    }
  }

  if (!desiredLink) return;

  for (uint16_t budget = 0; budget < ECL_TX_BURST; budget++) {
    if (!s_txPending) {
      uint8_t idx;
      if (xQueueReceive(s_txPriorityQ, &idx, 0) != pdTRUE &&
          xQueueReceive(s_txDataQ, &idx, 0) != pdTRUE) return;
      s_txPending = true;
      s_txPendingIndex = idx;
      s_txPendingSince = millis();
    }

    EclTxSlot& slot = s_txSlots[s_txPendingIndex];
    if (!slot.priority && millis() - slot.queuedAt > ECL_TX_MAX_AGE_MS) {
      eclTxReturn(s_txPendingIndex);
      s_txPending = false;
      eclStatInc(s_txDropped);
      continue;
    }

    if (!tud_network_can_xmit(slot.len)) {
      if (millis() - s_txPendingSince > ECL_TX_STALL_MS) {
        eclTxReturn(s_txPendingIndex);
        s_txPending = false;
        eclStatInc(s_txStalled);
      }
      return;
    }

    const uint8_t sentIndex = s_txPendingIndex;
    s_txPending = false;
    tud_network_xmit(slot.data, slot.len);
    eclTxReturn(sentIndex);
    eclStatInc(s_txSent);
  }
}

static void eclUsbNetServiceDeferred(void*) {
  portENTER_CRITICAL(&s_serviceMux);
  s_serviceScheduled = false;
  s_serviceScheduledAt = 0;
  portEXIT_CRITICAL(&s_serviceMux);
  eclUsbNetService();
}

extern "C" void ecl_net_driver_event(void) {
  eclUsbNetService();
}
#endif

static esp_err_t eclNetPostAttach(esp_netif_t* netif, esp_netif_iodriver_handle h) {
  esp_netif_driver_base_t* base = (esp_netif_driver_base_t*)h;
  base->netif = netif;
  return ESP_OK;
}

#if ECL_HAS_COPY_INPUT

static esp_netif_recv_ret_t eclEthernetInputCopy(void* h, void* buffer,
                                                 size_t len, void* l2Buffer) {
  (void)l2Buffer;
  struct netif* netif = (struct netif*)h;
  if (!netif || !buffer || len == 0 || len > 0xffffU ||
      !netif_is_up(netif) || !netif->input) {
    eclStatInc(s_rxDropped);
    return ESP_NETIF_OPTIONAL_RETURN_CODE(ESP_FAIL);
  }

  struct pbuf* p = pbuf_alloc(PBUF_RAW, (u16_t)len, PBUF_RAM);
  if (!p) {
    eclStatInc(s_rxDropped);
    return ESP_NETIF_OPTIONAL_RETURN_CODE(ESP_ERR_NO_MEM);
  }
  if (pbuf_take(p, buffer, len) != ERR_OK) {
    pbuf_free(p);
    eclStatInc(s_rxDropped);
    return ESP_NETIF_OPTIONAL_RETURN_CODE(ESP_FAIL);
  }

  eclSnatInbound((uint8_t*)p->payload, (uint16_t)len);

  if (netif->input(p, netif) != ERR_OK) {
    pbuf_free(p);
    eclStatInc(s_rxDropped);
    return ESP_NETIF_OPTIONAL_RETURN_CODE(ESP_ERR_NO_MEM);
  }
  return ESP_NETIF_OPTIONAL_RETURN_CODE(ESP_OK);
}

static esp_netif_netstack_config_t s_eclNetstack = {};
#else

static void eclNetFreeRx(void* h, void* buffer) {
  (void)h;
  free(buffer);
}
#endif

static esp_err_t eclNetTransmit(void* h, void* buffer, size_t len) {
  (void)h;
  if (!s_started || len == 0 || len > 0xffff) return ESP_ERR_INVALID_STATE;
  return eclNetTxFrame((const uint8_t*)buffer, (uint16_t)len) ? ESP_OK : ESP_FAIL;
}

#if ECL_NET_HAL
extern "C" {

bool tud_network_recv_cb(const uint8_t* src, uint16_t size) {

  if (s_started && s_rawBridge && src && size && size <= ECL_FRAME_SIZE) {
    eclStatInc(s_rxFrames);
    if (!s_rawReceive || !s_rawReceive(src, size, s_rawReceiveContext)) {
      eclStatInc(s_rxDropped);
    }
  } else if (s_started && s_netif && src && size && size <= ECL_FRAME_SIZE) {
    eclStatInc(s_rxFrames);
#if ECL_HAS_COPY_INPUT
    esp_netif_receive(s_netif, (void*)src, size, nullptr);
#else
    uint8_t* copy = (uint8_t*)malloc(size);
    if (copy) {
      memcpy(copy, src, size);
      eclSnatInbound(copy, size);
      esp_netif_receive(s_netif, copy, size, copy);
    } else {
      eclStatInc(s_rxDropped);
    }
#endif
  } else {
    eclStatInc(s_rxDropped);
  }

  tud_network_recv_renew();
  return true;
}

uint16_t tud_network_xmit_cb(uint8_t* dst, void* ref, uint16_t arg) {
  if (!dst || !ref || arg == 0) return 0;
  memcpy(dst, ref, arg);
  return arg;
}

void tud_network_init_cb(void) {
  s_linkUp = false;
  s_linkStateApplied = false;
  eclUsbNetService();
}

} // extern "C"
#endif

bool EvilCrowUsbNet::classSupported(EclNetClass cls) {
#if ECL_NET_HAL
  return ecl_net_driver_supports((uint8_t)cls);
#else
  (void)cls;
  return false;
#endif
}

bool EvilCrowUsbNet::beginRawBridge(EclNetClass cls, const uint8_t mac[6],
                                    EclNetRawRxCallback receive, void* context) {
#if ECL_NET_HAL
  if (s_started) return s_rawBridge;
  if (!mac || !receive || !classSupported(cls)) return false;

  ecl_net_driver_select((uint8_t)cls);
  _cls = cls;
  _ip = IPAddress(0, 0, 0, 0);
  _mask = IPAddress(0, 0, 0, 0);
  _gw = IPAddress(0, 0, 0, 0);
  _dns = IPAddress(0, 0, 0, 0);
  memcpy(_mac, mac, sizeof(_mac));
  memcpy(tud_network_mac_address, mac, sizeof(tud_network_mac_address));
  memcpy(s_devMac, mac, sizeof(s_devMac));

  Usb.enableNet(cls);

  if (!s_rawCallMutex) s_rawCallMutex = xSemaphoreCreateMutex();
  if (!s_rawAccess)    s_rawAccess    = xSemaphoreCreateMutex();
  if (!s_rawDone)      s_rawDone      = xSemaphoreCreateBinary();
  if (!s_rawCallMutex || !s_rawAccess || !s_rawDone) return false;

  while (xSemaphoreTake(s_rawDone, 0) == pdTRUE) {}
  s_rawPacket = nullptr;
  s_rawSendPending = false;
  s_rawBridge = true;
  s_rawReceive = receive;
  s_rawReceiveContext = context;
  s_rawCarrier = false;
  s_linkUp = false;
  s_linkStateApplied = false;
  s_naptEnabled = false;
  s_netif = nullptr;
  s_txPending = false;
  portENTER_CRITICAL(&s_serviceMux);
  s_serviceScheduled = false;
  s_serviceScheduledAt = 0;
  portEXIT_CRITICAL(&s_serviceMux);
  s_lastRecoveryKick = 0;
  eclStatsReset();

  s_started = true;
  _up = true;
  return true;
#else
  (void)cls; (void)mac; (void)receive; (void)context;
  return false;
#endif
}

bool EvilCrowUsbNet::begin(EclNetClass cls, IPAddress ip, IPAddress mask,
                           IPAddress gw, IPAddress dns) {
#if ECL_NET_HAL
  if (s_started) return true;
  if (!classSupported(cls)) return false;
  ecl_net_driver_select((uint8_t)cls);
  static const uint8_t routedMac[6] = {0x02,0x50,0xCA,0xDE,0x00,0x01};
  _cls = cls; _ip = ip; _mask = mask; _gw = gw; _dns = dns;
  memcpy(_mac, routedMac, sizeof(_mac));
  memcpy(tud_network_mac_address, _mac, 6);
  s_rawBridge = false;
  s_rawReceive = nullptr;
  s_rawReceiveContext = nullptr;
  s_rawCarrier = false;

  Usb.enableNet(cls);
  esp_netif_init();
  esp_err_t evt = esp_event_loop_create_default();
  if (evt != ESP_OK && evt != ESP_ERR_INVALID_STATE) return false;

  if (!s_txSlots)     s_txSlots     = (EclTxSlot*)malloc(sizeof(EclTxSlot) * ECL_TX_SLOTS);
  if (!s_txPriorityQ) s_txPriorityQ = xQueueCreate(ECL_TX_SLOTS, sizeof(uint8_t));
  if (!s_txDataQ)     s_txDataQ     = xQueueCreate(ECL_TX_SLOTS, sizeof(uint8_t));
  if (!s_txFreeQ)     s_txFreeQ     = xQueueCreate(ECL_TX_SLOTS, sizeof(uint8_t));
  if (!s_txSlots || !s_txPriorityQ || !s_txDataQ || !s_txFreeQ) return false;

  xQueueReset(s_txPriorityQ);
  xQueueReset(s_txDataQ);
  xQueueReset(s_txFreeQ);
  for (uint8_t i = 0; i < ECL_TX_SLOTS; i++) xQueueSend(s_txFreeQ, &i, 0);
  s_txPending = false;
  s_linkUp = false;
  s_linkStateApplied = false;
  portENTER_CRITICAL(&s_serviceMux);
  s_serviceScheduled = false;
  s_serviceScheduledAt = 0;
  portEXIT_CRITICAL(&s_serviceMux);
  s_lastRecoveryKick = 0;
  eclStatsReset();

  s_ipInfo.ip.addr      = (uint32_t)_ip;
  s_ipInfo.gw.addr      = (uint32_t)_gw;
  s_ipInfo.netmask.addr = (uint32_t)_mask;

  esp_netif_inherent_config_t base = {};
  base.flags   = (esp_netif_flags_t)(ESP_NETIF_FLAG_AUTOUP | ESP_NETIF_DHCP_SERVER);
  base.ip_info = &s_ipInfo;
  base.if_key  = "ECL_USBNET";
  base.if_desc = "usbnet";
  base.route_prio = 10;

  esp_netif_driver_ifconfig_t driver = {};
  driver.handle               = &s_driverBase;
  driver.transmit             = eclNetTransmit;
#if ECL_HAS_COPY_INPUT
  driver.driver_free_rx_buffer = nullptr;
#else
  driver.driver_free_rx_buffer = eclNetFreeRx;
#endif

  esp_netif_config_t cfg = {};
  cfg.base   = &base;
  cfg.driver = &driver;
#if ECL_HAS_COPY_INPUT
  s_eclNetstack.lwip.init_fn  = ethernetif_init;
  s_eclNetstack.lwip.input_fn = eclEthernetInputCopy;
  cfg.stack = &s_eclNetstack;
#else
  cfg.stack = ESP_NETIF_NETSTACK_DEFAULT_ETH;
#endif

  s_netif = esp_netif_new(&cfg);
  if (!s_netif) return false;

  s_driverBase.post_attach = eclNetPostAttach;
  if (esp_netif_attach(s_netif, &s_driverBase) != ESP_OK) {
    esp_netif_destroy(s_netif);
    s_netif = nullptr;
    return false;
  }

  uint8_t devMac[6];
  memcpy(devMac, tud_network_mac_address, 6);
  devMac[5] ^= 0x01;
  esp_netif_set_mac(s_netif, devMac);

  if (esp_netif_get_mac(s_netif, s_devMac) != ESP_OK) memset(s_devMac, 0, 6);
  if (memcmp(s_devMac, devMac, 6) != 0) {
#if ECL_HAS_NETSTACK
    struct netif* ln = (struct netif*)esp_netif_get_netif_impl(s_netif);
    if (ln) {
      memcpy(ln->hwaddr, devMac, 6);
      ln->hwaddr_len = 6;
      memcpy(s_devMac, devMac, 6);
    }
#endif
  }

  esp_netif_action_start(s_netif, nullptr, 0, nullptr);
  esp_netif_dhcps_stop(s_netif);
  esp_netif_set_ip_info(s_netif, &s_ipInfo);
  // Start with NO router/DNS offer - see the header comment. setAdvertisedRouter()
  // turns them on once something is actually forwarding.
  uint8_t off = 0;
  esp_netif_dhcps_option(s_netif, ESP_NETIF_OP_SET,
                         ESP_NETIF_ROUTER_SOLICITATION_ADDRESS, &off, sizeof(off));
  esp_netif_dhcps_option(s_netif, ESP_NETIF_OP_SET,
                         ESP_NETIF_DOMAIN_NAME_SERVER, &off, sizeof(off));
  esp_netif_dhcps_start(s_netif);
  esp_netif_action_connected(s_netif, nullptr, 0, nullptr);

  s_started = true;
  _up = true;
  return true;
#else
  (void)cls; (void)ip; (void)mask; (void)gw; (void)dns;
  return false;
#endif
}

void EvilCrowUsbNet::stop() {
  if (!s_started) return;
  if (s_naptEnabled && s_netif) {
    esp_netif_napt_disable(s_netif);
    s_naptEnabled = false;
  }
  if (s_netif) {
    esp_netif_action_stop(s_netif, nullptr, 0, nullptr);
    esp_netif_destroy(s_netif);
  }
  s_netif = nullptr;

#if ECL_NET_HAL
  if (s_rawBridge && s_rawAccess && xSemaphoreTake(s_rawAccess, portMAX_DELAY) == pdTRUE) {
    if (s_rawPacket) s_rawPacket->accepted = false;
    const bool wakeProducer = s_rawPacket != nullptr;
    s_rawPacket = nullptr;
    s_rawSendPending = false;
    xSemaphoreGive(s_rawAccess);
    if (wakeProducer && s_rawDone) xSemaphoreGive(s_rawDone);
  }
#endif
  s_started = false;
  s_rawCarrier = false;
  s_rawReceive = nullptr;
  s_rawReceiveContext = nullptr;
  s_rawBridge = false;
  s_snatOn = false;
  s_snatOperIp = 0;
  s_linkUp = false;
  s_linkStateApplied = false;
  portENTER_CRITICAL(&s_serviceMux);
  s_serviceScheduled = false;
  s_serviceScheduledAt = 0;
  portEXIT_CRITICAL(&s_serviceMux);
  _up = false;
}

void EvilCrowUsbNet::setAdvertisedRouter(IPAddress gw, IPAddress dns) {
  configureDhcp(true, gw, true, dns);
}

bool EvilCrowUsbNet::configureDhcp(bool offerRouter, IPAddress gw,
                                   bool offerDns, IPAddress dns) {
  if (!s_started || !s_netif) return false;
  _gw = gw; _dns = dns;

  esp_err_t stopResult = esp_netif_dhcps_stop(s_netif);
  if (stopResult != ESP_OK && stopResult != ESP_ERR_ESP_NETIF_DHCP_ALREADY_STOPPED) {
    return false;
  }

  esp_netif_dns_info_t di = {};
  di.ip.type = ESP_IPADDR_TYPE_V4;
  di.ip.u_addr.ip4.addr = (uint32_t)dns;
  if (esp_netif_set_dns_info(s_netif, ESP_NETIF_DNS_MAIN, &di) != ESP_OK) {
    esp_netif_dhcps_start(s_netif);
    return false;
  }

  uint8_t routerOffer = offerRouter ? 1 : 0;
  uint8_t dnsOffer = offerDns ? 1 : 0;
  if (esp_netif_dhcps_option(s_netif, ESP_NETIF_OP_SET,
                             ESP_NETIF_ROUTER_SOLICITATION_ADDRESS,
                             &routerOffer, sizeof(routerOffer)) != ESP_OK ||
      esp_netif_dhcps_option(s_netif, ESP_NETIF_OP_SET,
                             ESP_NETIF_DOMAIN_NAME_SERVER,
                             &dnsOffer, sizeof(dnsOffer)) != ESP_OK) {
    esp_netif_dhcps_start(s_netif);
    return false;
  }

  s_ipInfo.gw.addr = (uint32_t)gw;
  if (esp_netif_set_ip_info(s_netif, &s_ipInfo) != ESP_OK) {
    esp_netif_dhcps_start(s_netif);
    return false;
  }
  return esp_netif_dhcps_start(s_netif) == ESP_OK;
}

bool EvilCrowUsbNet::enableNapt(bool on) {
  if (!s_started || !s_netif) return false;
  if (on == s_naptEnabled) return true;
  esp_err_t e = on ? esp_netif_napt_enable(s_netif)
                   : esp_netif_napt_disable(s_netif);
  if (e == ESP_OK) s_naptEnabled = on;
  return e == ESP_OK;
}

bool EvilCrowUsbNet::naptEnabled() const { return s_naptEnabled; }

void EvilCrowUsbNet::setStatelessSnat(bool on, IPAddress deviceIp, IPAddress targetIp) {
  s_snatDevIp = (uint32_t)deviceIp;
  s_snatTgtIp = (uint32_t)targetIp;
  if (!on) s_snatOperIp = 0;
  s_snatOn = on;
}

bool EvilCrowUsbNet::statelessSnatEnabled() const { return s_snatOn; }

IPAddress EvilCrowUsbNet::snatOperator() const { return IPAddress((uint32_t)s_snatOperIp); }

bool EvilCrowUsbNet::rawBridgeMode() const { return s_started && s_rawBridge; }

void EvilCrowUsbNet::setRawBridgeLink(bool up) {
  if (!s_started || !s_rawBridge) return;
  s_rawCarrier = up;
  eclScheduleUsbService();
}

bool EvilCrowUsbNet::rawBridgeTransmit(const void* frame, uint16_t len,
                                       uint32_t timeoutMs) {
#if ECL_NET_HAL
  if (!s_started || !s_rawBridge || !s_rawCarrier || !tud_mounted() ||
      !frame || len == 0 ||
      len > ECL_FRAME_SIZE || !s_rawCallMutex || !s_rawAccess || !s_rawDone) {
    return false;
  }

  const TickType_t wait = timeoutMs == UINT32_MAX
                            ? portMAX_DELAY : pdMS_TO_TICKS(timeoutMs);
  if (xSemaphoreTake(s_rawCallMutex, wait) != pdTRUE) {
    eclStatInc(s_txDropped);
    return false;
  }

  while (xSemaphoreTake(s_rawDone, 0) == pdTRUE) {}

  EclRawTxPacket packet = {
    .data = (const uint8_t*)frame,
    .len = len,
    .accepted = false,
  };

  if (xSemaphoreTake(s_rawAccess, wait) != pdTRUE) {
    xSemaphoreGive(s_rawCallMutex);
    eclStatInc(s_txDropped);
    return false;
  }
  s_rawPacket = &packet;
  s_rawSendPending = true;
  xSemaphoreGive(s_rawAccess);
  eclScheduleUsbService();

  const bool signalled = xSemaphoreTake(s_rawDone, wait) == pdTRUE;

  xSemaphoreTake(s_rawAccess, portMAX_DELAY);
  if (s_rawPacket == &packet) {
    s_rawPacket = nullptr;
    s_rawSendPending = false;
  }
  xSemaphoreGive(s_rawAccess);

  if (!signalled) {
    eclStatInc(s_txStalled);
    eclStatInc(s_txDropped);
  }
  const bool accepted = signalled && packet.accepted;
  xSemaphoreGive(s_rawCallMutex);
  return accepted;
#else
  (void)frame; (void)len; (void)timeoutMs;
  return false;
#endif
}

bool EvilCrowUsbNet::linkUp() const {
#if ECL_NET_HAL
  return s_started && s_linkUp;
#else
  return false;
#endif
}

IPAddress EvilCrowUsbNet::hostIp() const {
  if (s_rawBridge) return IPAddress(0, 0, 0, 0);
  return IPAddress(_ip[0], _ip[1], _ip[2], _ip[3] + 1);
}

struct netif* EvilCrowUsbNet::lwipNetif() {
#if ECL_HAS_NETSTACK
  return s_netif ? (struct netif*)esp_netif_get_netif_impl(s_netif) : nullptr;
#else
  return nullptr;
#endif
}

esp_netif_t* EvilCrowUsbNet::espNetif() { return s_netif; }

const uint8_t* EvilCrowUsbNet::deviceMac() const { return s_devMac; }
const uint8_t* EvilCrowUsbNet::hostMac()   const { return tud_network_mac_address; }

void EvilCrowUsbNet::task() {
  uint32_t const now = millis();
  const uint32_t interval = eclTxWorkWaiting() ? 25U : 150U;
  if (now - s_lastRecoveryKick < interval) return;
  s_lastRecoveryKick = now;
  portENTER_CRITICAL(&s_serviceMux);
  if (s_serviceScheduled && now - s_serviceScheduledAt >= 100U) {
    s_serviceScheduled = false;
    s_serviceScheduledAt = 0;
  }
  portEXIT_CRITICAL(&s_serviceMux);
  eclScheduleUsbService();
}

void EvilCrowUsbNet::usbDiag(ecl_ncm_diag_t* out) const {
  if (!out) return;
#if ECL_NET_HAL
  ecl_net_driver_diag(out);
#else
  memset(out, 0, sizeof(*out));
#endif
}

uint32_t EvilCrowUsbNet::txSent()    const { return eclStatRead(s_txSent); }
uint32_t EvilCrowUsbNet::txDropped() const { return eclStatRead(s_txDropped); }
uint32_t EvilCrowUsbNet::rxFrames()  const { return eclStatRead(s_rxFrames); }
uint32_t EvilCrowUsbNet::txStalled() const { return eclStatRead(s_txStalled); }
uint32_t EvilCrowUsbNet::rxStuck()   const { return eclStatRead(s_rxDropped); }
