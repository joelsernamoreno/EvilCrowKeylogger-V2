#include "tusb_option.h"

#ifndef CFG_TUD_TASK_QUEUE_SZ
  #define CFG_TUD_TASK_QUEUE_SZ 32
#endif

#if TUSB_VERSION_NUMBER >= 2100 && TUSB_VERSION_NUMBER < 2200
  #include "ecl_tinyusb/usbd_021_ecl.inc"
#elif TUSB_VERSION_NUMBER >= 1800 && TUSB_VERSION_NUMBER < 1900
  #include "ecl_tinyusb/usbd_018_ecl.inc"
#else
  #error "EvilCrowLib: unsupported TinyUSB version for the usbd queue fix"
#endif

void ecl_usbd_edpt_force_idle(uint8_t rhport, uint8_t ep_addr) {
  (void) rhport;
  uint8_t const epnum = tu_edpt_number(ep_addr);
  uint8_t const dir   = tu_edpt_dir(ep_addr);

#if TUSB_VERSION_NUMBER >= 2100
  _usbd_dev.ep_status[epnum][dir] &=
      (uint8_t) ~(TU_EDPT_STATE_BUSY | TU_EDPT_STATE_CLAIMED);
#else
  _usbd_dev.ep_status[epnum][dir].busy = 0;
  _usbd_dev.ep_status[epnum][dir].claimed = 0;
#endif
}
