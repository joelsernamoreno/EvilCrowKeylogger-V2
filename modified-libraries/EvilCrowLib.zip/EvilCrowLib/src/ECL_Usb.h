#pragma once
#include <Arduino.h>
#include <functional>
#include <vector>
#include <stdint.h>

enum EclNetClass : uint8_t {
  ECL_NET_OFF   = 0,
  ECL_NET_NCM   = 1,   // CDC-NCM
  ECL_NET_ECM   = 2,   // CDC-ECM
  ECL_NET_RNDIS = 3,   // RNDIS
};

enum EclHidReportId : uint8_t {
  ECL_RID_KEYBOARD = 1,
  ECL_RID_MOUSE    = 2,
  ECL_RID_CONSUMER = 3,
  ECL_RID_SYSTEM   = 4,
  ECL_RID_RAW      = 5,
  ECL_RID_CUSTOM   = 6,
};

struct EclUsbConfig {
  uint16_t vid = 0x303A;
  uint16_t pid = 0x1001;
  const char* manufacturer = "Generic";
  const char* product      = "Composite Device";
  const char* serial       = "0001";
  uint16_t bcdDevice = 0x0108;
  uint16_t  power_ma  = 500;
};

struct EclHidFragment {
  const uint8_t* report_desc;
  uint16_t       report_len;
  bool           wants_out;
};

class EvilCrowUSB {
public:
  EvilCrowUSB();

  void enableHid(const EclHidFragment& frag);
  void enableMsc();
  void enableNet(EclNetClass cls);
  void setConfig(const EclUsbConfig& cfg) { _cfg = cfg; }
  EclUsbConfig& config() { return _cfg; }
  void setNetClass(EclNetClass cls);
  EclNetClass netClass() const { return _netClass; }

  bool begin();
  bool mounted() const;
  void task();

  bool hidReady() const;
  bool hidSendReport(uint8_t report_id, const void* data, uint8_t len);

  using LedCb = std::function<void(uint8_t leds)>;
  void onKeyboardLeds(LedCb cb) { _ledCb = cb; }
  void _dispatchLeds(uint8_t leds) { if (_ledCb) _ledCb(leds); }

  using RawCb = std::function<void(const uint8_t* data, uint16_t len)>;
  void onRawHid(RawCb cb) { _rawCb = cb; }
  void _dispatchRaw(const uint8_t* d, uint16_t l) { if (_rawCb) _rawCb(d, l); }
  const uint8_t* hidReportDescriptor(uint16_t* out_len) const;
  static EvilCrowUSB& instance();

private:
  EclUsbConfig _cfg;
  EclNetClass  _netClass = ECL_NET_OFF;
  bool _useHid = false, _useMsc = false;
  bool _installed = false;

  std::vector<uint8_t> _hidReport;

  LedCb  _ledCb;
  RawCb  _rawCb;

  void buildHidReport(const std::vector<EclHidFragment>& frags);
  std::vector<EclHidFragment> _frags;
};

extern EvilCrowUSB Usb;
